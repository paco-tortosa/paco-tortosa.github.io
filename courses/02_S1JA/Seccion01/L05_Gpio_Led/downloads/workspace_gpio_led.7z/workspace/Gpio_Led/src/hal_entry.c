/* HAL-only entry function */
#include "hal_data.h"


void delay(void);
void delay(void)
{
    volatile int32_t i;
    for(i=0;
        i < 100000;
        i++);
}

void hal_entry(void)
{
    for(;;) {
        g_ioport_on_ioport.pinWrite(IOPORT_PORT_00_PIN_15,
                                    IOPORT_LEVEL_HIGH);
        delay();
        g_ioport_on_ioport.pinWrite(IOPORT_PORT_00_PIN_15,
                                    IOPORT_LEVEL_LOW);
        delay();
    }
}
