/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

#define CMD_DECODE_MODE 0x09
#define CMD_INTENSITY   0x0A
#define CMD_SCAN_LIMIT  0x0B
#define CMD_SHUTDOWN    0x0C

void SendCommand (  uint8   _u8Command,
                    uint8   _u8Data)
{
    Pin_CS_Write(0);
    
    SPIM_WriteByte(_u8Command);
    SPIM_WriteByte(_u8Data);

    while(0u == (SPIM_ReadTxStatus() & SPIM_STS_SPI_DONE))
    {
        // Wait while Master completes transaction
    }    
    
    Pin_CS_Write(1);
}

void DisplayNumber (uint32 _u32Number)
{
    SendCommand(1, _u32Number             % 10);
    SendCommand(2,(_u32Number / 10)       % 10);
    SendCommand(3,(_u32Number / 100)      % 10);
    SendCommand(4,(_u32Number / 1000)     % 10);
    SendCommand(5,(_u32Number / 10000)    % 10);
    SendCommand(6,(_u32Number / 100000)   % 10);
    SendCommand(7,(_u32Number / 1000000)  % 10);
    SendCommand(8,(_u32Number / 10000000) % 10);
}

int main(void)
{
    uint32  u32Counter  =   0;
    CyGlobalIntEnable; /* Enable global interrupts. */

    SPIM_Start();
    
    Pin_CS_Write(1);
   
    SendCommand(CMD_SHUTDOWN    ,1);    //Normal Operation
    SendCommand(CMD_DECODE_MODE ,0xFF); //BCD coded all digits
    SendCommand(CMD_SCAN_LIMIT  ,0x07); //All digits displayed
    SendCommand(CMD_INTENSITY   ,0x2);  //Intensity 0..15
    
    for(;;)
    {
        DisplayNumber(u32Counter++);
        CyDelay(50);        
    }
}

/* [] END OF FILE */
