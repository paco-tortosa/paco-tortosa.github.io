/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

#define CMD_WREN        0x06
#define CMD_READ_MEM    0x03
#define CMD_WRITE_MEM   0x02

const   uint8   au8Constants1[] =   { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11};
const   uint8   au8Constants2[] =   {12,13,14,15,16,17,18,19,20,21,22,23};
        uint8   au8FromMemory[sizeof(au8Constants1)];

///////////////////////////////////////////
// SpiWriteByte
///////////////////////////////////////////
uint8   SpiWriteByte(  uint8   _u8Data)
{
    SPIM_WriteByte(_u8Data);

    // Wait while Master completes transaction
    while(0u == (SPIM_ReadTxStatus() & SPIM_STS_SPI_DONE));

    // Wait until the received byte is in the RX-buffer
    while(SPIM_GetRxBufferSize() != 1);
    
    // Returns the received byte.
    return SPIM_ReadByte();
}
        
///////////////////////////////////////////
// FramWriteMem
///////////////////////////////////////////
void FramWriteMem(  uint16  _u16Address,
                    uint8*  _pu8Data,
                    uint16  _u16DataCount)
{
    uint16  u16Idx;
    uint8   u8AddressByteHigh   =   _u16Address >> 8;
    uint8   u8AddressByteLow    =   _u16Address & 0xFF;
    
    Pin_CS_Write(0);
        SpiWriteByte(CMD_WREN);
    Pin_CS_Write(1);
    
    Pin_CS_Write(0);
        SpiWriteByte(CMD_WRITE_MEM);
        SpiWriteByte(u8AddressByteHigh);
        SpiWriteByte(u8AddressByteLow );
        
        for(u16Idx  =   0;
            u16Idx  <   _u16DataCount;
            u16Idx++)
        {
            SpiWriteByte(_pu8Data[u16Idx]);
        }
    Pin_CS_Write(1);
}

///////////////////////////////////////////
// FramReadMem
///////////////////////////////////////////
void FramReadMem(   uint16  _u16Address,
                    uint8*  _pu8Data,
                    uint16  _u16DataCount)
{
    uint16  u16Idx;
    uint8   u8AddressByteHigh   =   _u16Address >> 8;
    uint8   u8AddressByteLow    =   _u16Address & 0xFF;
    
    Pin_CS_Write(0);
        SpiWriteByte(CMD_READ_MEM);
        SpiWriteByte(u8AddressByteHigh);
        SpiWriteByte(u8AddressByteLow );
        
        for(u16Idx  =   0;
            u16Idx  <   _u16DataCount;
            u16Idx++)
        {
            _pu8Data[u16Idx]    =   SpiWriteByte(0);
        }
    Pin_CS_Write(1);
}

///////////////////////////////////////////
// main
///////////////////////////////////////////
int main(void)
{
    // Enable global interrupts.
    CyGlobalIntEnable; 

    SPIM_Start();

    Pin_CS_Write(1);
    Pin_WP_Write(1);
    Pin_HOLD_Write(1);

    FramWriteMem(   0x0000, (uint8*)au8Constants1,sizeof(au8Constants1));
    FramReadMem (   0x0000,         au8FromMemory,sizeof(au8FromMemory));

    FramWriteMem(   0x0000, (uint8*)au8Constants2,sizeof(au8Constants2));
    FramReadMem (   0x0000,         au8FromMemory,sizeof(au8FromMemory));
    
    for(;;)
    {
    }
}

/* [] END OF FILE */
