/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

#define POT_CHAN    (0)

int main()
{
    volatile int16  i16Counts;
    volatile int16  i16mVolts;
    
    CyGlobalIntEnable; /* Enable global interrupts. */

    ADC_Start();
    ADC_StartConvert();

    for(;;)
    {
        i16Counts   =   ADC_GetResult16(POT_CHAN);
        i16mVolts   =   ADC_CountsTo_mVolts(POT_CHAN,i16Counts);
    }
}

/* [] END OF FILE */
