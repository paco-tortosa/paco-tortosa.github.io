/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

int main()
{
    volatile    uint8   u8OldStatus =   0;
    volatile    uint8   u8Status    =   0;
    volatile    uint8   u8Times     =   0;

    CyGlobalIntEnable; /* Enable global interrupts. */

    for(;;)
    {
        u8Status        =   StatusRegister_Read();
        if (u8Status != u8OldStatus)
        {
            u8Times++;
            u8OldStatus =   u8Status;
        }
    }
}

/* [] END OF FILE */
