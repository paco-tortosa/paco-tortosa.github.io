﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KiCad_BOM
{
    public partial class FormMain: Form
    {
        private const   int                                 k_iRef          =   0;
        private const   int                                 k_iValue        =   1;
        private const   int                                 k_iFootprint    =   2;
        private const   int                                 k_iDatasheet    =   3;
        private const   int                                 k_iValue2Show   =   4;
        private const   int                                 k_iMounted      =   5;
        private const   int                                 k_iMPN          =   6;
        private const   int                                 k_iManufacturer =   7;
        private         Dictionary<string, List<cComp_t>>   m_DictComp      =   new Dictionary<string, List<cComp_t>>();

        public FormMain()
        {
            InitializeComponent();
        }

        private string m_GetBOM( string _strSeparator )
        {
            string  strBOM                      =   "Quantity"      + _strSeparator +
                                                    "Value"         + _strSeparator +
                                                    "Value2Show"    + _strSeparator +
                                                    "MPN"           + _strSeparator +
                                                    "Manufacturer"  + _strSeparator +   
                                                    "References"    + "\n";

            foreach( var pair in m_DictComp )
            {
                List<cComp_t>   lcComp          =   pair.Value;

                //Mounted???
                string          strMounted      =   lcComp[0].m_strMounted;
                if( strMounted.ToUpper() != "YES" )
                {
                    continue;
                }
                //Quantity
                int             iQuantity       =   lcComp.Count;
                //Value
                string          strValue        =   lcComp[0].m_strValue;
                //Value2Show
                string          strValue2Show   =   lcComp[0].m_strValue2Show;
                //MPN
                string          strMPN          =   lcComp[0].m_strMPN;
                //Manufacturer
                string          strManufacturer =   lcComp[0].m_strManufacturer;
                //References
                string          strReferences   =   "";
                foreach( cComp_t cComp in pair.Value )
                {
                    if( strReferences.Length > 0 )
                    {
                        strReferences           +=  ",";
                    }
                    strReferences               +=  cComp.m_strReference;
                }
                //Line for BOM
                strBOM                          +=  iQuantity       + _strSeparator +
                                                    strValue        + _strSeparator +
                                                    strValue2Show   + _strSeparator +
                                                    strMPN          + _strSeparator +
                                                    strManufacturer + _strSeparator +   
                                                    strReferences   + "\n";
            }
            return  strBOM;
        }

        private int m_GetFieldNumber( string _strLine )
        {
            if( string.IsNullOrEmpty( _strLine ) )
            {
                return -1;
            }
            if( _strLine.Substring(0,1) == "F" )
            {
                int     iUntil          =   _strLine.Substring(2).IndexOf( " " );
                string  strField        =   _strLine.Substring(2, iUntil);
                int     iFieldNumber    =   0;
                if( int.TryParse( strField , out iFieldNumber ) )
                {
                    return iFieldNumber;
                }
            }
            return -1;
        }

        private List<string>    m_GetStrings ( string _strLine )
        {
            List<string>    l2Return    =   new List<string>();
            bool            bInString   =   false;
            string          strString   =   "";

            foreach( var c in _strLine )
            {
                if( c == '"' )
                {
                    if( bInString )
                    {
                        l2Return.Add( strString );
                        bInString       =   false;
                        strString       =   "";
                    }
                    else
                    {
                        bInString       =   true;
                    }
                }
                else if ( bInString )
                {
                    strString   +=  c;
                }
            }
            return  l2Return;
        }

        private void btnGetDirectory_Click(object sender, EventArgs e)
        {
            m_DictComp.Clear();
            var             fbd     =   new FolderBrowserDialog();
            DialogResult    dg      =   fbd.ShowDialog();
            if( dg == DialogResult.OK )
            {
                tbDirectory.Text    =   fbd.SelectedPath;
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                rtbOutput.Clear();

                DirectoryInfo   di  =   new DirectoryInfo( tbDirectory.Text.Trim() );
                if( ! di.Exists )
                {
                    MessageBox.Show( "El directorio [" + di.FullName + "] no existe", "Error");
                    return;
                }

                //Get all files .sch in the directory
                foreach( string strFilename in Directory.GetFiles(  tbDirectory.Text.Trim(),
                                                                    "*.sch"))
                {
                    cComp_t cComp   =   null;
                    foreach( string strLine in File.ReadAllLines( strFilename ) )
                    {
                        if( strLine.IndexOf("$Comp") == 0 )
                        {
                            cComp   =   new cComp_t();
                        }
                        else if( strLine.IndexOf("$EndComp") == 0 )
                        {
                            if( ! m_DictComp.ContainsKey( cComp.m_strValue ) )
                            {
                                m_DictComp.Add( cComp.m_strValue , new List<cComp_t>() );
                            }
                            m_DictComp[cComp.m_strValue].Add( cComp );
                            cComp   =  null;
                        }
                        else if ( cComp != null )
                        {
                            if( ! string.IsNullOrEmpty( strLine ) )
                            {
                                if( strLine.Substring(0,1) == "F" )
                                {
                                    int             iFieldNumber    =   m_GetFieldNumber( strLine );
                                    List<string>    lstrings        =   m_GetStrings( strLine );

                                    switch( iFieldNumber )
                                    {
                                        case k_iRef:
                                            cComp.m_strReference    =   lstrings[0];
                                            break;
                                        case k_iValue:
                                            cComp.m_strValue        =   lstrings[0];
                                            break;
                                        default:
                                            if( lstrings.Count == 2 )
                                            {
                                                switch( lstrings[1].ToUpper() )
                                                {
                                                    case "VALUE2SHOW":
                                                        cComp.m_strValue2Show   =   lstrings[0];
                                                        break;
                                                    case "MOUNTED":
                                                        cComp.m_strMounted      =   lstrings[0];
                                                        break;
                                                    case "MPN":
                                                        cComp.m_strMPN          =   lstrings[0];
                                                        break;
                                                    case "MANUFACTURER":
                                                        cComp.m_strManufacturer =   lstrings[0];
                                                        break;
                                                }
                                            }
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }

                //Get BOM text
                rtbOutput.Text          =   m_GetBOM( this.tbSeparator.Text );

                //Save the file 
                string  strCSVFilename  =   di.FullName + Path.DirectorySeparatorChar + "BOM.csv";
                File.WriteAllText(  strCSVFilename,
                                    rtbOutput.Text);
                MessageBox.Show("File [" + strCSVFilename + "] generated", "Ok");
            }
            catch ( Exception ex )
            {
                MessageBox.Show( ex.Message , "Error" );
                return;
            }
        }
    }
}
