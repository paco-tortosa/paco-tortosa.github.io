﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KiCad_BOM
{
    class cComp_t
    {
        public  string  m_strReference      =   "";
        public  string  m_strValue          =   "";
        public  string  m_strValue2Show     =   "";
        public  string  m_strMounted        =   "";
        public  string  m_strMPN            =   "";
        public  string  m_strManufacturer   =   "";
    }
}
