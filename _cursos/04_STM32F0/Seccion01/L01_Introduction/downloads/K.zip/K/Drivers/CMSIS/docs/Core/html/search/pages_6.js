var searchData=
[
  ['system_20partition_20header_20file_20partition_5f_3cdevice_3e_2eh',['System Partition Header File partition_&lt;device&gt;.h',['../partition_h_pg.html',1,'templates_pg']]],
  ['startup_20file_20startup_5f_3cdevice_3e_2es',['Startup File startup_&lt;device&gt;.s',['../startup_s_pg.html',1,'templates_pg']]],
  ['system_20configuration_20files_20system_5f_3cdevice_3e_2ec_20and_20system_5f_3cdevice_3e_2eh',['System Configuration Files system_&lt;device&gt;.c and system_&lt;device&gt;.h',['../system_c_pg.html',1,'templates_pg']]]
];
