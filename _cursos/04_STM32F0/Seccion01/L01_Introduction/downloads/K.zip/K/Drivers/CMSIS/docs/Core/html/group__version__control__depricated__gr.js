var group__version__control__depricated__gr =
[
    [ "__XXX_CMSIS_VERSION", "group__version__control__depricated__gr.html#gabea7df329b150f620ee42f9d82516241", null ],
    [ "__XXX_CMSIS_VERSION_MAIN", "group__version__control__depricated__gr.html#ga2ecc1658e18eb1a0be7959e33b836d05", null ],
    [ "__XXX_CMSIS_VERSION_SUB", "group__version__control__depricated__gr.html#ga962096f43e0d194f0b79021964c57fbd", null ]
];