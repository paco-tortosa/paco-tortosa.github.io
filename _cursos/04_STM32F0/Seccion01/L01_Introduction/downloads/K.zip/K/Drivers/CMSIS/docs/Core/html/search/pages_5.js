var searchData=
[
  ['revision_20history_20of_20cmsis_2dcore_20_28cortex_2dm_29',['Revision History of CMSIS-Core (Cortex-M)',['../core_revisionHistory.html',1,'']]],
  ['register_20mapping',['Register Mapping',['../regMap_pg.html',1,'']]]
];
