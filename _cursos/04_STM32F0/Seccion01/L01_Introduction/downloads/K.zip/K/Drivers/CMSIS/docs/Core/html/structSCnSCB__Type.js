var structSCnSCB__Type =
[
    [ "ACTLR", "structSCnSCB__Type.html#a13af9b718dde7481f1c0344f00593c23", null ],
    [ "ICTR", "structSCnSCB__Type.html#a34ec1d771245eb9bd0e3ec9336949762", null ],
    [ "RESERVED0", "structSCnSCB__Type.html#afe1d5fd2966d5062716613b05c8d0ae1", null ]
];