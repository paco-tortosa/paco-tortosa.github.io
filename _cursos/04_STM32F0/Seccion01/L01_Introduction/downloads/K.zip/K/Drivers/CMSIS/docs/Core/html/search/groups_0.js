var searchData=
[
  ['cache_20functions_20_20_28only_20cortex_2dm7_29',['Cache Functions  (only Cortex-M7)',['../group__cache__functions__m7.html',1,'']]],
  ['compiler_20control',['Compiler Control',['../group__compiler__conntrol__gr.html',1,'']]],
  ['core_20register_20access',['Core Register Access',['../group__Core__Register__gr.html',1,'']]],
  ['core_20register_20access_20functions',['Core Register Access Functions',['../group__coreregister__trustzone__functions.html',1,'']]]
];
