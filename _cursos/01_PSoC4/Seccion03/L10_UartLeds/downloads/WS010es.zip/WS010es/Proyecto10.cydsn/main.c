/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    UART_Start();
    UART_UartPutString("Envia 1 para led rojo, 2 para led verde y 3 para led azul \n");

    for(;;)
    {
        char ch_rx  =   UART_UartGetChar();
        
        if (ch_rx != 0)
        {
            Pin_Rojo_Write(1);
            Pin_Verde_Write(1);
            Pin_Azul_Write(1);

            if (ch_rx == '1')
            {
                Pin_Rojo_Write(0);
            }
            else if (ch_rx == '2')
            {
                Pin_Verde_Write(0);
            }
            else if (ch_rx == '3')
            {
                Pin_Azul_Write(0);
            }
        }
    }
}

/* [] END OF FILE */
