/*******************************************************************************
* File Name: ClockDebouncer.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_ClockDebouncer_H)
#define CY_CLOCK_ClockDebouncer_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void ClockDebouncer_StartEx(uint32 alignClkDiv);
#define ClockDebouncer_Start() \
    ClockDebouncer_StartEx(ClockDebouncer__PA_DIV_ID)

#else

void ClockDebouncer_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void ClockDebouncer_Stop(void);

void ClockDebouncer_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 ClockDebouncer_GetDividerRegister(void);
uint8  ClockDebouncer_GetFractionalDividerRegister(void);

#define ClockDebouncer_Enable()                         ClockDebouncer_Start()
#define ClockDebouncer_Disable()                        ClockDebouncer_Stop()
#define ClockDebouncer_SetDividerRegister(clkDivider, reset)  \
    ClockDebouncer_SetFractionalDividerRegister((clkDivider), 0u)
#define ClockDebouncer_SetDivider(clkDivider)           ClockDebouncer_SetDividerRegister((clkDivider), 1u)
#define ClockDebouncer_SetDividerValue(clkDivider)      ClockDebouncer_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define ClockDebouncer_DIV_ID     ClockDebouncer__DIV_ID

#define ClockDebouncer_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define ClockDebouncer_CTRL_REG   (*(reg32 *)ClockDebouncer__CTRL_REGISTER)
#define ClockDebouncer_DIV_REG    (*(reg32 *)ClockDebouncer__DIV_REGISTER)

#define ClockDebouncer_CMD_DIV_SHIFT          (0u)
#define ClockDebouncer_CMD_PA_DIV_SHIFT       (8u)
#define ClockDebouncer_CMD_DISABLE_SHIFT      (30u)
#define ClockDebouncer_CMD_ENABLE_SHIFT       (31u)

#define ClockDebouncer_CMD_DISABLE_MASK       ((uint32)((uint32)1u << ClockDebouncer_CMD_DISABLE_SHIFT))
#define ClockDebouncer_CMD_ENABLE_MASK        ((uint32)((uint32)1u << ClockDebouncer_CMD_ENABLE_SHIFT))

#define ClockDebouncer_DIV_FRAC_MASK  (0x000000F8u)
#define ClockDebouncer_DIV_FRAC_SHIFT (3u)
#define ClockDebouncer_DIV_INT_MASK   (0xFFFFFF00u)
#define ClockDebouncer_DIV_INT_SHIFT  (8u)

#else 

#define ClockDebouncer_DIV_REG        (*(reg32 *)ClockDebouncer__REGISTER)
#define ClockDebouncer_ENABLE_REG     ClockDebouncer_DIV_REG
#define ClockDebouncer_DIV_FRAC_MASK  ClockDebouncer__FRAC_MASK
#define ClockDebouncer_DIV_FRAC_SHIFT (16u)
#define ClockDebouncer_DIV_INT_MASK   ClockDebouncer__DIVIDER_MASK
#define ClockDebouncer_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_ClockDebouncer_H) */

/* [] END OF FILE */
