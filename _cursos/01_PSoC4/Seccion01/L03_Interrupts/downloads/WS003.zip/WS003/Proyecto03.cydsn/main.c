/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

CY_ISR( Pin_SW2_Handler )
{
    Pin_Rojo_Write( ~ Pin_Rojo_Read() ); 
    Pin_SW2_ClearInterrupt();
}

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    Pin_SW2_Int_StartEx(Pin_SW2_Handler);
    
    for(;;)
    {
        Pin_Azul_Write(1);
        CyDelay(500);
        Pin_Azul_Write(0);
        CyDelay(500);
    }
}

/* [] END OF FILE */
