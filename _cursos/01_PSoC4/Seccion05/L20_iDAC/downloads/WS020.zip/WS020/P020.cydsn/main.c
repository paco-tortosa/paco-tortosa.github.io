/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    uint8   u8Current   =   0;

    CyGlobalIntEnable; /* Enable global interrupts. */

    IDAC_Start();

    for(;;)
    {
        IDAC_SetValue(u8Current++);
    }
}

/* [] END OF FILE */
