/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

#define POT_CHAN        (0)
#define MAX_ADC_VALUE   0x7FF

CY_ISR(ISR_ADC_EOC_Handler)
{
    volatile int16  i16Counts;
    volatile int16  i16mVolts;
    
    i16Counts   =   ADC_GetResult16(POT_CHAN);
    i16mVolts   =   ADC_CountsTo_mVolts(POT_CHAN,i16Counts);

    ADC_EOC_Write( ~ ADC_EOC_Read());
    
    if (i16Counts < MAX_ADC_VALUE / 3)
    {
        LED_RED_Write(1);
        LED_GREEN_Write(1);
        LED_BLUE_Write(0);
    }
    else if (i16Counts < 2 * MAX_ADC_VALUE / 3)
    {
        LED_RED_Write(1);
        LED_GREEN_Write(0);
        LED_BLUE_Write(1);
    }
    else 
    {
        LED_RED_Write(0);
        LED_GREEN_Write(1);
        LED_BLUE_Write(1);
    }
    
    ISR_ADC_EOC_ClearPending();
}

int main()
{
    
    CyGlobalIntEnable; /* Enable global interrupts. */

    ADC_Start();
    ISR_ADC_EOC_StartEx(ISR_ADC_EOC_Handler);
    ADC_StartConvert();

    for(;;)
    {
    }
}

/* [] END OF FILE */
